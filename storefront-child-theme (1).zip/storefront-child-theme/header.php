<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package storefront
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
<style>
    #masthead{
        text-align: center;
        color: #fff;
        background-color: #043785;
        margin: 0;
        padding: 24px !important
    }
    .topbar h4{
        color: #fff;
        font-weight: 600;
        margin: 0;
    }
    .topbar p{
        margin: 0;
    }
    .site-footer{
        background-color: #fff;
    }
    .site-info, .site-info a{
        color: #21C1AA !important;
    }
    .topbar .btn {
    border: 1px solid #fff;
    border-radius: 6px;
    font-size: 17px;
    font-weight: 500;
    line-height: 1.33;
    margin: 5px 10px;
    padding: 12px 16px;
    text-transform: uppercase;
}

.topbar .btn-white {
    background: #043785 none repeat scroll 0 0;
    color: #ffffff;
}
.topbar .btn-primary {
    background: #ffffff none repeat scroll 0 0;
    color: #043785;
}
.create-demo-container #cbs-register input[type="text"] {
    background: #ffffff;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin: 10px;
}
.input-text, input[type=email], input[type=password], input[type=search], input[type=tel], input[type=text], input[type=url], textarea {
    padding: .6180469716em;
    background-color: #f2f2f2;
    color: #43454b;
    outline: 0;
    border: 0;
    -webkit-appearance: none;
    box-sizing: border-box;
    font-weight: 400;
    box-shadow: inset 0 1px 1px rgb(0 0 0 / 13%);
}
.create-demo-container .form-submit .submit.button {
    background: #007acc;
    color: #ffffff;
    font-weight: 500;
    text-transform: capitalize;
    border-radius: 4px;
    font-size: 16px;
}
.entry-header{
    padding-top: 50px;
}
.entry-content .wp-block-heading {
    display: none;
}
#masthead{
    padding: 32px;
    font-size: 20px;
}
#cbs_register{
    background-color: #043785;
    color: #fff;
    border-radius: 8px;
}
.entry-content{
	padding: 40px;
	border: 0.5px solid #ddd;
}
.entry-header {
    padding: 0 !important;
    display: none;
}
#primary {
    margin: 0 auto;
}
.col-full {
    display: flex;
}
.site-info {
    display: none;
}

</style>
</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<?php do_action( 'storefront_before_site' ); ?>

<div id="page" class="hfeed site">
    
	<?php //do_action( 'storefront_before_header' ); ?>

	<header id="masthead" class="site-header" role="banner" style="<?php storefront_header_styles(); ?>">
	    <div class="topbar">
	        <div style="display: flex; gap: 10px; align-items: center; justify-content: space-between; max-width: 1280px; margin: 0 auto;">
	            <h4>UpsellWP Full Demo</h4>
	            <div>
	                <a href="https://wordpress.org/plugins/checkout-upsell-and-order-bumps/" class="btn btn-white">Download</a> 
        		    <a href="https://upsellwp.com/pricing/" class="btn btn-primary">Buy now</a> </h4><br />
	            </div>
	        </div>
	    </div>

		<?php
		/**
		 * Functions hooked into storefront_header action
		 *
		 * @hooked storefront_header_container                 - 0
		 * @hooked storefront_skip_links                       - 5
		 * @hooked storefront_social_icons                     - 10
		 * @hooked storefront_site_branding                    - 20
		 * @hooked storefront_secondary_navigation             - 30
		 * @hooked storefront_product_search                   - 40
		 * @hooked storefront_header_container_close           - 41
		 * @hooked storefront_primary_navigation_wrapper       - 42
		 * @hooked storefront_primary_navigation               - 50
		 * @hooked storefront_header_cart                      - 60
		 * @hooked storefront_primary_navigation_wrapper_close - 68
		 */
		//do_action( 'storefront_header' );
		?>

	</header><!-- #masthead -->
	
	<div style="text-align: center; margin: 24px; font-weight: 600px;">
		<h4>
			Create UpsellWP demo by clicking the Create Demo button below
		</h4>
	</div>

	<?php
	/**
	 * Functions hooked in to storefront_before_content
	 *
	 * @hooked storefront_header_widget_region - 10
	 * @hooked woocommerce_breadcrumb - 10
	 */
	//do_action( 'storefront_before_content' );
	?>

	<div id="content" class="site-content" tabindex="-1">
		<div class="col-full" >

		<?php
		//do_action( 'storefront_content_top' );
