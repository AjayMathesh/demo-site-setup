<?php
/**
 * Plugin Name: Create Demo Sub-Sites
 * Plugin URI: http://www.cozmsolabs.com
 * Description: Gives you access to a shortcode that allows anyone to automatically create a subsite for testing purposes [cds_register]
 * Version: 1.0.1
 * Author: Cozmoslabs
 * Author URI: http:/www.cozmoslabs.com
 * License: GPL2
 */
/* Copyright Cozmoslabs.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

// Start writing code after this line!

// Add a Simple Math Captcha
include_once 'math-captcha.php';

// Need sessions for the Math Captcha
add_action('init', 'cds_start_session');
function cds_start_session()
{
    session_start();
}

// Create the shortcode that will output the Create Demo button.
add_shortcode('cds_register', 'cds_register');
function cds_register()
{

    $cpa = new MathCaptcha();
    if (('POST' == $_SERVER['REQUEST_METHOD']) && ($_POST['cbs_action'] == 'cbs_demo')) {
        $captcha_val = $_REQUEST['captcha'];

        if (!$cpa->validate($captcha_val)) {
            return '<p>Incorect Captcha. Please try again. You will be redirected in 3 seconds <meta http-equiv="refresh" content="3"></p>';
        }

        // Multisite domain
        $main_site = DOMAIN_CURRENT_SITE;

        do {
            $rand = 'user-' . cbs_rand_string();
            if (is_subdomain_install()) {
                $newdomain = "{$rand}.$main_site";
                $path = '/';
            } else {
                $newdomain = $main_site;
                $path = PATH_CURRENT_SITE . "{$rand}/";
            }
        } while (username_exists($rand) && domain_exists($newdomain, $path));

        // Create the new user
        $username = $rand;
        $email = $rand . '@demo.upsellwp.com';
        $password = 'demo';
        $user_id = wpmu_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            return '<p>The new demo account could not be created. Please try again. (You will be redirected in 5 seconds) <meta http-equiv="refresh" content="5"></p>';
        }

        // Create the new sub-site
        $title = 'Demo';
        $blog_id = wpmu_create_blog($newdomain, $path, $title, $user_id, array('public' => 1));

        if (is_wp_error($blog_id)) {
            return '<p>The new demo account could not be created. Please try again. (You will be redirected in 5 seconds) <meta http-equiv="refresh" content="5"></p>';
        }

        $location = get_site_url($blog_id);
        $nonce = wp_create_nonce('cds_autologin-' . $user_id . '-' . (int) (time() / 60));
        $location .= "/?cds_autologin=true&uid=$user_id&_wpnonce=$nonce";
        
        echo '<p>Creating a new demo instance for you...</p>';
        echo '<p>NOTE: This demo instance will expire after 4 hours.</p>';

        return "<script> window.location.replace('$location'); </script>";

    } else {
        $cpa->reset_captcha();
        ob_start();
        ?>
            <form enctype="multipart/form-data" method="post" id="cbs-register" action="">
                <p><?php
                    echo 'Solve this simple Math: ' . $cpa->get_captcha_text() . " = ";
                ?>&nbsp;
                <input name="captcha" type="text" value="" placeholder="?" style="max-width: 128px;" />
                </p>
                <p class="form-submit">
                    <input name="cbs_register" type="submit" id="cbs_register" class="submit button" value="Create Demo" />
                    <input name="cbs_action" type="hidden" id="cbs_action" value="cbs_demo" />
                </p>
            </form>
		<?php
        $output = ob_get_contents();
        ob_end_clean();

        return $output;
    }
}

// A simple and almost random string generator.
// We don't really need 100% random strings, so sha1 will do just fine.
function cbs_rand_string($length = 8)
{
    return substr(md5(uniqid()), 0, $length);
}

/*
 * Setup Autologin after creation of demosite
 */
/* set action for automatic login after registration */
add_action('init', 'cds_autologin_after_creation');
function cds_autologin_after_creation()
{
    if (isset($_GET['cds_autologin']) && isset($_GET['uid'])) {
        $uid = $_GET['uid'];
        $nonce = $_REQUEST['_wpnonce'];

        $arr_params = array('cds_autologin', 'uid', '_wpnonce');
        $current_page_url = remove_query_arg($arr_params, cds_curpageurl());

        if (!(wp_verify_nonce($nonce, 'cds_autologin-' . $uid . '-' . (int) (time() / 60)) || wp_verify_nonce($nonce, 'cds_autologin-' . $uid . '-' . (int) (time() / 60) - 1))) {
            wp_redirect($current_page_url);
            exit;
        } else {
            wp_set_auth_cookie($uid);
            wp_redirect($current_page_url . 'wp-admin/');
            exit;
        }
    }
}

function cds_curpageurl()
{
    $pageURL = 'http';

    if ((isset($_SERVER["HTTPS"])) && ($_SERVER["HTTPS"] == "on")) {
        $pageURL .= "s";
    }

    $pageURL .= "://";

    if ($_SERVER["SERVER_PORT"] != "80") {
        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
    } else {
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    }

    if (function_exists('apply_filters')) {
        apply_filters('wppb_curpageurl', $pageURL);
    }

    return $pageURL;
}

/**
 * Schedule event hourly to delete old subsites
 */
register_activation_hook(__FILE__, 'cds_cron_to_delete_subsites_activation');
function cds_cron_to_delete_subsites_activation()
{
    wp_schedule_event(time(), 'hourly', 'cds_check_subsites_hourly_event');
}

register_deactivation_hook(__FILE__, 'cds_cron_to_delete_subsites_deactivation');
function cds_cron_to_delete_subsites_deactivation()
{
    wp_clear_scheduled_hook('cds_check_subsites_hourly_event');
}

/**
 * Delete subsites registered for more than 12 hours
 *
 * Only deletes subsites where super-admin is not part of the site's users
 */
function cds_check_subsites_for_deletion()
{

    require_once ABSPATH . 'wp-admin/includes/admin.php';
    // get sites
    global $wpdb;
    $args = array(
        'network_id' => $wpdb->siteid,
    );
    $sites_array = wp_get_sites($args);
    $current_time = current_time('timestamp');

    foreach ($sites_array as $site) {
        // get each blog's users and check if super-admin is the creator so that it will not be deleted
        $user_args = array(
            'blog_id' => $site['blog_id'],
        );
        $users = get_users($user_args);

        $delete_this_site = true;
        foreach ($users as $user) {
            if (is_super_admin($user)) {
                $delete_this_site = false;
                break;
            }
        }

        $register_time = strtotime($site['registered'], current_time('mysql'));
        $time_since_registration = $current_time - $register_time;

        // if the site has been created for more than 14400 seconds = 4 hours, delete it
        if ($delete_this_site && ($time_since_registration > 14400)) {
            if (!function_exists('wpmu_delete_blog')) {
                return;
            }

            if (!in_array($site['blog_id'], ['1', '2'])) {
                wpmu_delete_blog($site['blog_id'], true);
            }
        }
    }
}
add_action('cds_check_subsites_hourly_event', 'cds_check_subsites_for_deletion');

add_filter( 'wpmu_drop_tables', 'delete_wdr_plugin_tables', 10, 2 );
function delete_wdr_plugin_tables( $tables=array(), $blog_id=null ) {
    /**
     * Make sure the blog ID parameter was sent, so we don't
     * 	accidentally delete tables for the wrong blog
     */
    if ( empty( $blog_id ) || $blog_id == 2  ) {
        return $tables;
    }
    
    global $wpdb;
    
    $blog_tables = [];
    $blog_prefix = $wpdb->get_blog_prefix( $blog_id );
    $blog_tables_data = $wpdb->get_results("SHOW TABLES LIKE '$blog_prefix%'");
    foreach ($blog_tables_data as $blog_table_object) {
        foreach ($blog_table_object as $blog_table_name) { 
            $blog_tables[] = $blog_table_name;
        }
    }
    
    if (!empty($blog_tables)) {
        return $blog_tables;
    }
    
    return $tables;
}

// for debugging purpose
//
// add_action('admin_init', 'cds_check_subsites_for_deletion');
//
// function dd($data)
// {
//     ini_set("highlight.comment", "#969896; font-style: italic");
//     ini_set("highlight.default", "#FFFFFF");
//     ini_set("highlight.html", "#D16568");
//     ini_set("highlight.keyword", "#7FA3BC; font-weight: bold");
//     ini_set("highlight.string", "#F2C47E");
//     $output = highlight_string("<?php\n".var_export($data, true), true);
//     echo '<pre style="background:#111; padding:10px">'.$output.'</pre>';
//     die();
// }


add_action('wp_footer', function () { ?>
    <script type="text/javascript">
        (function(c,l,a,r,i,t,y){
            c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
            t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
            y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
        })(window, document, "clarity", "script", "mfiyozrdim");
    </script>
<?php
});

add_action('admin_footer', function () { 
    if (function_exists('get_current_user_id') && get_current_user_id() == 1) {
        return;
    }
    ?>
    <script type="text/javascript">
        (function(c,l,a,r,i,t,y){
            c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
            t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
            y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
        })(window, document, "clarity", "script", "mfiyozrdim");
    </script>
<?php
});

