<?php
/**
 * Plugin name: Flycart Demo Promotion
 * Plugin URI: http://www.flycart.org
 * Description: Plugin helps to show promotions in admin dashboard, buy now and visit site links in admin bar, etc.
 * Author: Flycart Technologies LLP
 * Author URI: https://www.flycart.org
 * Version: 1.0.0
 * Slug: flycart-demo-promotion
 * Text Domain: flycart-demo-promotion
 */
defined('ABSPATH') or exit;

// The plugin path
defined('FDP_PLUGIN_PATH') or define('FDP_PLUGIN_PATH', plugin_dir_path(__FILE__));

// The plugin url
defined('FDP_PLUGIN_URL') or define('FDP_PLUGIN_URL', plugin_dir_url(__FILE__));

// The plugin text domain
defined('FDP_TEXT_DOMAIN') or define('FDP_TEXT_DOMAIN', 'flycart-demo-promotion');

/**
 * Init plugin
 */
include_once(__DIR__ . "/src/Main.php");

new \FDP\Main();