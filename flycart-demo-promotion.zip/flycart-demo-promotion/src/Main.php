<?php
namespace FDP;

defined('ABSPATH') or exit;

class Main
{
    public $flycart_plugins = [
        'discount_rules' => [
            'name' => "Discount Rules for WooCommerce - PRO",
            'menu_name' => "Woo Discount Rules",
            'menu_icon' => "dashicons-cart",
            'description' => "Create Dynamic Pricing and Discounts in your WooCommerce online store easily. Bulk discounts, cart discounts, special offers, user role based discounts and more.",
            'path' => "woo-discount-rules/woo-discount-rules.php",
            'admin_url' => "admin.php?page=woo_discount_rules",
            'purchase_url' => "https://www.flycart.org/products/wordpress/woocommerce-discount-rules",
            'product_icon' => "discount-rules.png",
            'popular' => true,
            'new' => false,
        ],
        'email_customizer' => [
            'name' => "Email Customizer Plus for WooCommerce",
            'menu_name' => "Email Customizer Plus",
            'menu_icon' => "dashicons-email-alt",
            'description' => "Customize your WooCommerce Emails with a drag and drop editor. Change the logo, text, header, footer and more. You can customize everything in the WooCommerce order notification emails.",
            'path' => "woocommerce-email-customizer-plus/woocommerce-email-customizer-plus.php",
            'admin_url' => "admin.php?page=woocommerce-email-customizer-plus",
            'purchase_url' => "https://www.flycart.org/products/wordpress/woocommerce-email-customizer",
            'product_icon' => "email-builder.png",
            'popular' => false,
            'new' => false,
        ],
        'wp_loyalty' => [
            'name' => "WPLoyalty - Points & Rewards for WooCommerce",
            //'menu_name' => "WPLoyalty",
            //'menu_icon' => "dashicons-megaphone",
            'description' => "Reward, Retain & Grow sales organically! Reward customers for their loyalty & for referring their friends using the best WooCommerce Points and Rewards plugin.",
            'path' => "wp-loyalty-rules/wp-loyalty-rules.php",
            'admin_url' => "admin.php?page=wp-loyalty-rules",
            'purchase_url' => "https://wployalty.net/pricing",
            'product_icon' => "wployalty.png",
            'popular' => false,
            'new' => false,
        ],
        'checkout_upsell' => [
            'name' => "UpsellWP - WooCommerce Upsell, Cross-sell and Order Bumps",
            //'menu_name' => "Checkout Upsell",
            //'menu_icon' => "dashicons-cart",
            'description' => "Increase the average order value with smart offers at checkout. Add one-click upsells and order bumps to your WooCommerce store page and motivate customers to buy more.",
            'path' => "checkout-upsell-woocommerce/checkout-upsell-woocommerce.php",
            'admin_url' => "admin.php?page=checkout-upsell-woocommerce",
            'purchase_url' => "https://upsellwp.com/pricing/",
            'product_icon' => "checkout-upsell.png",
            'popular' => false,
            'new' => true,
        ],
        'retainful' => [
            'name' => "Retainful - Abandoned Cart Recovery",
            //'menu_name' => "Retainful",
            //'menu_icon' => "dashicons-controls-repeat",
            'description' => "Grow sales on Auto-pilot by sending the right emails at right time automatically. Interact with customers at every step of their journey. Automate email marketing and minimize manual workload with Retainful.",
            'path' => "retainful-next-order-coupon-for-woocommerce/retainful-next-order-coupon-for-woocommerce.php",
            'admin_url' => "admin.php?page=retainful_license",
            'purchase_url' => "https://www.retainful.com/pricing",
            'product_icon' => "retainful.png",
            'popular' => false,
            'new' => false,
        ],
    ];

    public function __construct()
    {
        add_action('admin_menu', array($this, 'AddMenu'));
        add_action('admin_notices', array($this, 'promotions'));
        add_action('admin_bar_menu', array($this, 'buyNow'), 100);
        add_action('admin_bar_menu', array($this, 'visitSite'), 100);
        add_action('admin_enqueue_scripts', array($this, 'enqueueAssets'), 100);
        add_action('wp_enqueue_scripts', array($this, 'enqueueAssets'), 100);
    }

    /**
     * Add Admin Side Bar menu
     */
    function AddMenu()
    {
        $plugin = $this->activePlugin();
        if (isset($plugin['menu_name']) && isset($plugin['admin_url'])) {
            add_menu_page(
                "Flycart Demo",
                $plugin['menu_name'],
                "manage_options",
                $plugin['admin_url'],
                "",
                isset($plugin['menu_icon']) ? $plugin['menu_icon'] : "dashicons-cart",
                20
            );
        }
    }

    /**
     * Find current active plugin
     *
     * @return array
     */
    function activePlugin()
    {
        $active_plugins = apply_filters('active_plugins', get_option('active_plugins', []));
        if (is_multisite()) {
            $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', []));
        }

        foreach ($this->flycart_plugins as $key => $plugin) {
            if (isset($plugin['path']) && (in_array($plugin['path'], $active_plugins) || array_key_exists($plugin['path'], $active_plugins))) {
                $plugin['id'] = $key;
                return $plugin;
            }
        }
        return [];
    }

    /**
     * Show flycart plugins promotion panel
     */
    public function promotions()
    {
        global $pagenow;
        if (!is_admin() || empty($pagenow) || $pagenow != 'index.php') {
            return;
        } ?>
        <div id="flycart-promotion" class="promotion-panel">
            <div class="promotion-panel-content">
                <h2><?php _e('Our Premium WooCommerce Plugins', FDP_TEXT_DOMAIN); ?></h2>
                <p class="promotion-description"><?php _e('Check out our premium WooCommerce plugins that can help boost your sales and revenue, retain customers and recover abandoned carts', FDP_TEXT_DOMAIN); ?></p>
                <div class="promotion-panel-column-container">
                <?php foreach ($this->flycart_plugins as $key => $plugin) { ?>
                    <?php
                        $img_url = isset($plugin['product_icon']) ? FDP_PLUGIN_URL . 'assets/img/' . $plugin['product_icon'] : "";
                        $purchase_url = isset($plugin['purchase_url']) ? $plugin['purchase_url'] : "";
                    ?>
                    <div class="promotion-panel-column">
                        <div class="promotion-panel-card">
                            <h3>
                                <?php _e($plugin['name'], FDP_TEXT_DOMAIN); ?>
                                <?php if ($plugin['popular']) echo '<span class="promotion-badge-popular">Popular</span>'; ?>
                                <?php if ($plugin['new']) echo '<span class="promotion-badge-new">New</span>'; ?>
                            </h3>
                            <div class="promotion-panel-body">
                                <img src="<?php echo $img_url;?>" alt="Icon">
                                <span><?php _e($plugin['description'], FDP_TEXT_DOMAIN); ?></span>
                            </div>
                            <div style="text-align: center">
                                <a class="button button-primary promotion-panel-button" href="<?php echo $purchase_url;?>" target="_blank"><?php _e('View Details', FDP_TEXT_DOMAIN); ?></a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Show Buy Now link in Admin Bar
     *
     * @param $wp_admin_bar
     */
    public function buyNow($wp_admin_bar)
    {
        $plugin = $this->activePlugin();
        $purchase_url = isset($plugin['purchase_url']) ? $plugin['purchase_url'] : "";
        $wp_admin_bar->add_node([
            'id' => 'flycart-' . $plugin['id'],
            'parent' => 'top-secondary',
            'title' => 'Buy this plugin now',
            'href' => $purchase_url,
            'meta' => [
                'class' => 'flycart-buy-now',
                'title' => $plugin['name'],
                'target' => '_blank',
            ],
        ]);
    }

    /**
     * Show Visit Site link in Admin Bar
     *
     * @param $wp_admin_bar
     */
    public function visitSite($wp_admin_bar)
    {
        $wp_admin_bar->remove_node('search');

        if (is_admin() && function_exists('wc_get_page_id')) {
            $wp_admin_bar->add_node([
                'id' => 'flycart-site-link',
                'title' => 'Visit Site',
                'href' => get_permalink(wc_get_page_id('shop')),
                'meta' => [
                    'class' => 'flycart-visit-site',
                    'title' => 'Go to Site',
                    'target' => '_blank',
                ],
            ]);
        }
    }

    /**
     * Enqueue styles and scripts
     */
    public function enqueueAssets()
    {
        wp_enqueue_style('fdp-admin', FDP_PLUGIN_URL . 'assets/css/fdp.css');
        wp_enqueue_script('fdp-admin', FDP_PLUGIN_URL . 'assets/js/fdp.js');
    }
}